<div class="container">
    <h2><?php echo esc_html($fudge_lite_connect_title); ?></h2>
    <?php get_template_part('menu', 'social'); ?>
</div>