=== Fudge Lite Core ===
Contributors: showthemes
Tags: fudge-lite
Requires at least: 4.4
Tested up to: 4.7
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Contains all core functionality for Fudge Lite theme

== Description ==

Contains all core functionality for Fudge Lite theme

Please install and activate the plugin before installing Fudge Lite theme.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/fudge-lite-core` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings->Plugin Name screen to configure the plugin
1. (Make your instructions match the desired user flow for activating and installing your plugin. Include any steps that might be needed for explanatory purposes)

== Frequently Asked Questions ==

= Why do I need to install this plugin? =

Fudge Lite Core contains all core data (post types) necessary for Fudge Lite to work.

== Changelog ==

= 1.0 =
* First release


== Upgrade Notice ==

= 1.0 =
Please activate the plugin before installing Fudge Lite theme.