<style>
    /** Fixes min-width for long sidebar nav **/
    #adminmenu .wp-not-current-submenu .wp-submenu li.vcv-dashboard-admin-menu--add {
        min-width: 220px;
    }
</style>